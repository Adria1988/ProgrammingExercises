


def hotel(string, hash = { :name_room => adios} )
  puts hash[:name_room]

end

 hotel("hilbert's grand hotel", "Basement"=>4, "Attic"=>2, "Under the Stairs"=>1)
